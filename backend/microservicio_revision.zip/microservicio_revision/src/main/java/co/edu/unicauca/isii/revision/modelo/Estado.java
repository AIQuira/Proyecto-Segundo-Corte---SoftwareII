package co.edu.unicauca.isii.revision.modelo;

public enum Estado {
    RECIBIDO, 
    EN_REVISION, 
    ACEPTADO, 
    RECHAZADO
}
