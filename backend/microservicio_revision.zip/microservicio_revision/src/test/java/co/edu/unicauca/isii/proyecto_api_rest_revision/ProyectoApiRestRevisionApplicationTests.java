package co.edu.unicauca.isii.proyecto_api_rest_revision;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoApiRestRevisionApplicationTests {

	@Test
	void contextLoads() {
	}

}
